import React from "react";
import { useDispatch } from "react-redux";
import { toggleTaskCompletion, deleteTask } from "../redux/taskSlice";
import "./TaskItem.css";

const TaskItem = ({ id, title, description, date, completed }) => {
  const dispatch = useDispatch();

  const handleToggleCompletion = () => {
    dispatch(toggleTaskCompletion(id));
  };

  const handleDeleteTask = () => {
    dispatch(deleteTask(id));
  };

  return (
    <li className={`task-item ${completed ? "task-item-success" : ""}`}>
      <div className="task-item-content">
        <span className="task-item-title">
          <input
            type="checkbox"
            className="task-item-checkbox"
            checked={completed}
            onChange={handleToggleCompletion}
          />
          {title}
        </span>
        <div className="task-item-details">
          <p className="task-item-description">{description}</p>
          <p className="task-item-date">Date: {date}</p>
        </div>
        <button className="task-item-delete" onClick={handleDeleteTask}>
          Delete
        </button>
      </div>
    </li>
  );
};

export default TaskItem;
