import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { addTask } from "../redux/taskSlice"; 
import "./AddTaskForm.css";

const AddTaskForm = () => {
  const [value, setValue] = useState("");
  const dispatch = useDispatch();

  const onSubmit = (event) => {
    event.preventDefault();
    console.log("user entered: " + value);
    dispatch(
      addTask({
        task: value,
        taskItem: (
          <TaskItem
            id={1}
            title="Complete project"
            description="Finish the task manager project by next week."
            date="2024-02-14"
            completed={false}
          />
        ),
        taskList: [
          {
            id: 1,
            title: "Task 1",
            description: "Description 1",
            date: "2024-02-12",
            completed: false,
          },
          {
            id: 2,
            title: "Task 2",
            description: "Description 2",
            date: "2024-02-13",
            completed: true,
          },
        ],
      })
    );
  };

  return (
    <form onSubmit={onSubmit} className="add-task-form">
      <label className="visually-hidden">Name</label>
      <input
        type="text"
        className="task-input"
        placeholder="Add task..."
        value={value}
        onChange={(event) => setValue(event.target.value)}
      />
      <button type="submit" className="submit-button">
        Submit
      </button>
    </form>
  );
};

export default AddTaskForm;
