import React from "react";
import { useSelector } from "react-redux";
import { selectTaskItems } from "../redux/taskSlice";
import "./TotalCompleteItems.css";

const TotalCompleteItems = () => {
  const taskItems = useSelector(selectTaskItems);
  const totalCompleteItems = taskItems.filter((item) => item.completed).length;

  return (
    <h4 className="total-complete-items">
      Total Complete Items: {totalCompleteItems}
    </h4>
  );
};

export default TotalCompleteItems;
