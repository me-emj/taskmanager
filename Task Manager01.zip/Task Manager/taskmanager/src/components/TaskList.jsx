import React from "react";
import { useSelector } from "react-redux";
import TaskItem from "./TaskItem";
import { selectTaskList } from "../redux/taskSlice";
import "./TaskList.css";

const TaskList = () => {
  const taskList = [
    {
      id: 1,
      title: "Task 1",
      description: "Description for Task 1",
      date: "2024-02-14",
      completed: false,
    },
    {
      id: 2,
      title: "Task 2",
      description: "Description for Task 2",
      date: "2024-02-15",
      completed: false,
    },
    {
      id: 3,
      title: "Task 3",
      description: "Description for Task 3",
      date: "2024-02-16",
      completed: true,
    },
    {
      id: 4,
      title: "Task 4",
      description: "Description for Task 4",
      date: "2024-02-17",
      completed: false,
    },
    {
      id: 5,
      title: "Task 5",
      description: "Description for Task 5",
      date: "2024-02-18",
      completed: true,
    },
  ];

  return (
    <ul className="task-list">
      {taskList.map((task) => (
        <TaskItem
          key={task.id}
          id={task.id}
          title={task.title}
          description={task.description}
          date={task.date}
          completed={task.completed}
        />
      ))}
    </ul>
  );
};

export default TaskList;
