import { createSlice } from "@reduxjs/toolkit";

export const taskSlice = createSlice({
  name: "task",
  initialState: {
    tasks: [],
    taskItems: [],
    taskList: [],
  },
  reducers: {
    addTask: (state, action) => {
      state.tasks.push(action.payload.task);
      state.taskItems.push(action.payload.taskItem);
      state.taskList.push(action.payload.taskList);
    },
    toggleTaskCompletion: (state, action) => {
      const taskId = action.payload;
      const taskIndex = state.taskItems.findIndex((task) => task.id === taskId);
      if (taskIndex !== -1) {
        state.taskItems[taskIndex].completed =
          !state.taskItems[taskIndex].completed;
      }
    },
    deleteTask: (state, action) => {
      const taskId = action.payload;
      state.tasks = state.tasks.filter((task) => task.id !== taskId);
      state.taskItems = state.taskItems.filter((task) => task.id !== taskId);
      state.taskList = state.taskList.filter((task) => task.id !== taskId);
    },
  },
});

export const { addTask, toggleTaskCompletion, deleteTask } = taskSlice.actions;
export const selectTasks = (state) => state.task.tasks;
export const selectTaskItems = (state) => state.task.taskItems;
export const selectTaskList = (state) => state.task.taskList;

export default taskSlice.reducer;
