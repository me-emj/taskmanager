import React, { useState } from "react";
import AddTaskForm from "./components/AddTaskForm";
import TaskList from "./components/TaskList";
import TotalCompleteItems from "./components/TotalCompleteItems";
import Login from "./components/auth/Login";

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLogin = () => {
    setIsLoggedIn(true);
  };

  return (
    <div className="container bg-white p-4 mt-5">
      {isLoggedIn ? (
        <div>
          <h1>My Tasks</h1>
          <AddTaskForm />
          <TaskList />
          <TotalCompleteItems />
        </div>
      ) : (
        <Login onLogin={handleLogin} />
      )}
    </div>
  );
};

export default App;
